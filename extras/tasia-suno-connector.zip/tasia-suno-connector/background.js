function makeUuid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function normalizeBaseUrl(value) {
  return String(value || '').trim().replace(/\/+$/, '');
}

function cleanDeviceId(value) {
  let v = String(value || '').trim();
  try { v = decodeURIComponent(v); } catch {}
  v = v.replace(/^['"]+|['"]+$/g, '').trim();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v) ? v.toLowerCase() : '';
}

async function getCookie(url, name) {
  try { return await chrome.cookies.get({url, name}); } catch { return null; }
}

async function getSunoSession() {
  // Prefer the Clerk auth-domain __client value, matching current suno-cli.
  const authClient = await getCookie('https://auth.suno.com/', '__client');
  const siteClient = await getCookie('https://suno.com/', '__client');
  const client = authClient || siteClient;
  if (!client?.value) throw new Error('No Suno __client session found. Log into suno.com first.');

  const anon = await getCookie('https://suno.com/', 'ajs_anonymous_id');
  const authAnon = await getCookie('https://auth.suno.com/', 'ajs_anonymous_id');
  let deviceId = cleanDeviceId(anon?.value || authAnon?.value || '');
  if (!deviceId) {
    const stored = await chrome.storage.local.get(['fallbackDeviceId']);
    deviceId = cleanDeviceId(stored.fallbackDeviceId || '');
    if (!deviceId) {
      deviceId = makeUuid();
      await chrome.storage.local.set({fallbackDeviceId: deviceId});
    }
  }
  return {clerkClientCookie: client.value, deviceId};
}

async function sendSession(reason = 'manual sync') {
  const data = await chrome.storage.local.get(['tasiaUrl', 'connectorKey']);
  const tasiaUrl = normalizeBaseUrl(data.tasiaUrl);
  const connectorKey = String(data.connectorKey || '').trim();
  if (!tasiaUrl || !connectorKey) return {ok:false, error:'Configure Tasia Streamer URL and connector key first'};

  try {
    const session = await getSunoSession();
    const response = await fetch(`${tasiaUrl}/api/suno/connector/session`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        connector_key: connectorKey,
        clerk_client_cookie: session.clerkClientCookie,
        device_id: session.deviceId
      })
    });
    const text = await response.text();
    let payload = {};
    try { payload = text ? JSON.parse(text) : {}; } catch { payload = {detail:text}; }
    if (!response.ok) throw new Error(payload.detail || `HTTP ${response.status}`);
    await chrome.storage.local.set({
      lastSync: Date.now(), lastError: '', lastReason: reason,
      connectedUsername: payload.username || '', refreshable: !!payload.refreshable
    });
    return {ok:true, payload};
  } catch (error) {
    const message = String(error?.message || error);
    await chrome.storage.local.set({lastError:message, lastReason:reason});
    return {ok:false, error:message};
  }
}

let syncTimer = null;
function scheduleSync(reason) {
  clearTimeout(syncTimer);
  syncTimer = setTimeout(() => sendSession(reason), 700);
}

chrome.cookies.onChanged.addListener(change => {
  const c = change.cookie;
  if (!c || !String(c.domain || '').includes('suno.com')) return;
  if (c.name === '__client' || c.name === 'ajs_anonymous_id') scheduleSync('Suno session changed');
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.action === 'syncNow') {
    sendSession('manual sync').then(sendResponse);
    return true;
  }
  if (message?.action === 'status') {
    Promise.all([
      chrome.storage.local.get(['tasiaUrl','connectorKey','lastSync','lastError','lastReason','connectedUsername','refreshable']),
      getSunoSession().then(() => true).catch(() => false)
    ]).then(([data, sessionFound]) => sendResponse({...data, sessionFound}));
    return true;
  }
});
