Tasia Suno Connector v1.1.0

1. Load this folder as an unpacked Chrome/Chromium extension.
2. In Tasia Streamer > Settings > Suno connection, generate/copy the connector key.
3. Paste your Streamer URL and connector key into this extension.
4. Stay logged into your own account at suno.com and click Save & Sync.

The extension reads only Suno's __client Clerk session cookie and device ID after explicit pairing. It does not read the rest of your browsing cookies and no longer captures Authorization/Bearer headers. The session is sent only to the Tasia Streamer origin you approve.
